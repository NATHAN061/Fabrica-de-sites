const input= document.querySelector("#formulario input");
const criar = document.querySelector("#formulario button"); 
const area = document.getElementById('area');
const lista = document.createElement('ul');
let atividades = [];

lista.id = "lista-atividades";
area.appendChild(lista);

const modelo=document.createElement('li')
modelo.innerHTML = "<div class='card-atividade'><input type='checkbox'> <p>${atividade}</p></div>";
lista.appendChild(modelo);
